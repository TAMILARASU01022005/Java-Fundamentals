package Array;

import java.util.Scanner;

public class Average {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int sum = 0;
        double avg = 0;
        System.out.print("Enter the Size of an Array : ");
        int size = sc.nextInt();
        int[] arr = new int[size];
        System.out.print("Enter the Array Elements : ");
        for (int i = 0; i<size; i++){
            arr[i] = sc.nextInt();
        }

        for(int i=0; i<arr.length; i++){
            sum = sum + arr[i];
            avg = sum/size;
        }
        System.out.print("The avg of the given array elements are : "+avg);
        sc.close();
    }
}
