package Array;

import java.util.Scanner;

public class MinMax {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the Size of the Array : ");
        int size = sc.nextInt();
        int[] arr = new int[size];
        System.out.print("Enter the Array Elements : ");
        for (int i = 0; i<size; i++){
            arr[i] = sc.nextInt();
        }
        int max = arr[0];
        int min = arr[0];
        for(int i=1; i<arr.length; i++){
            if(arr[i]>max){
                max = arr[i];
                System.out.print("The max number in this array is : " + max);
            }
            if(arr[i]<min){
                min = arr[i];
                System.out.println("The min number in this array is : " + min);
            }
        }
        sc.close();
    }
}
