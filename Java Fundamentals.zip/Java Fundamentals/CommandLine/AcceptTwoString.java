public class AcceptTwoString {
     public static void main(String[] var0) {
      if (var0.length == 2) {
         String var1 = var0[0];
         String var2 = var0[1];
         String var3 = var1 + " Technologies " + var2;
         System.out.println(var3);
      } else {
         System.out.println("Please provide exactly two command line arguments.");
      }

   }
}
