package CommandLine;
public class AddString {
    public static void main(String[] args) {
        if (args.length == 1) {
            String name = args[0];
            System.out.println("Welcome " + name);
        } else {
            System.out.println("Please provide exactly one name as a command line argument.");
        }
    }
}
