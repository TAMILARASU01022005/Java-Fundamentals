public class PrintMidNumber {
    public static void main(String[] args) {
        int i=0;
        for(i=23;i<58;i++){
            if(i%2==0){
                System.out.println(i);
            }
        }
    }
}
