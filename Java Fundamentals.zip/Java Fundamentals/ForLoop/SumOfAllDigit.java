import java.util.Scanner;

public class SumOfAllDigit {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the number : ");
        int n=sc.nextInt();
        int sum=0;
        for (; n > 0; n /= 10){
            int rem=n%10;
            sum=sum+rem;
        }
        System.out.println(sum);
        sc.close();
    }
}
