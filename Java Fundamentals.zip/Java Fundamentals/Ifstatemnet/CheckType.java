import java.util.Scanner;

public class CheckType {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter the Char : ");
        char ch=sc.next().charAt(0);
        if(Character.isAlphabetic(ch)){
            System.out.println("Alphabetic");
        }
        else if(Character.isDigit(ch)){
            System.out.println("Digit");
        }
        else{
            System.out.println("Special Character");
        }
        sc.close();
    }
}
