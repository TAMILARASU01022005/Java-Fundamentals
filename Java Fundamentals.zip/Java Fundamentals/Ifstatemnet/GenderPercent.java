import java.util.Scanner;

public class GenderPercent {
    public static void main(String[] args) {
        Scanner sc=new Scanner (System.in);
        System.out.println("Enter the Age : ");
        int age = sc.nextInt();
        System.out.println("Enter the Gender : ");
        String gender = sc.next();
        if(gender.equals("Female")){
            if(age>=1 && age<=58){
                System.out.println("The percentage of female is 8.2");
            }
            else{
                System.out.println("The percentage of female is 9.2");
            }
        }
        if(gender.equals("Male")){
            if(age>=1 && age<=58){
                System.out.println("The percentage of female is 8.4");
            }
            else{
                System.out.println("The percentage of female is 10.5");
            }
        }
        sc.close();
    }
}
