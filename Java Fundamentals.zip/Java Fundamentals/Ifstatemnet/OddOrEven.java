import java.util.Scanner;

public class OddOrEven {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a number: ");
        int number = sc.nextInt();
        if(number %2==0){
            System.out.println(number + " is even");
        }
        else if(number %2==1){
            System.out.println(number + " is odd");
        }
        else{
            System.out.println("This number is Zero");
        }
        sc.close();
    }
}
