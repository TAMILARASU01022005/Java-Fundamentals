package WhileLoop;

public class Divisible {
    public static void main(String[] args) {
        int count = 0;
        int num=1;
        System.out.print("The 1st 5 Numbers which is divisible by 2, 3, 5 are : ");
        while (count<=5){
            if(num%2==0 && num%3==0 && num%5==0){
                System.out.print(num+" ");
                count++;
            }
            num++;
        }
    }
}
